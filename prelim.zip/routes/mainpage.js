const express = require('express');
const router = express.Router();

const Video = require('../controller/VideoController');

// TODO: Change to real render
// TODO: Fix bug
router.get('/', function (req, res, next) {
    // Get top 10 like videos
    Video.findTopTenVideos()
        .then(function (list) {

        });
    res.send('main page');
});

module.exports = router;
